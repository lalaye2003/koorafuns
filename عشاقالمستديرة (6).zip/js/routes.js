angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('page1', {
    url: '/page1',
    templateUrl: 'templates/page1.html',
    controller: 'page1Ctrl'
  })

  .state('page2', {
    url: '/page2',
    templateUrl: 'templates/page2.html',
    controller: 'page2Ctrl'
  })

  .state('page3', {
    url: '/page3',
    templateUrl: 'templates/page3.html',
    controller: 'page3Ctrl'
  })

  .state('page5', {
    url: '/page5',
    templateUrl: 'templates/page5.html',
    controller: 'page5Ctrl'
  })

  .state('page6', {
    url: '/page6',
    templateUrl: 'templates/page6.html',
    controller: 'page6Ctrl'
  })

  .state('page7', {
    url: '/page7',
    templateUrl: 'templates/page7.html',
    controller: 'page7Ctrl'
  })

  .state('page8', {
    url: '/page8',
    templateUrl: 'templates/page8.html',
    controller: 'page8Ctrl'
  })

  .state('page9', {
    url: '/page9',
    templateUrl: 'templates/page9.html',
    controller: 'page9Ctrl'
  })

  .state('page10', {
    url: '/page10',
    templateUrl: 'templates/page10.html',
    controller: 'page10Ctrl'
  })

  .state('page11', {
    url: '/page11',
    templateUrl: 'templates/page11.html',
    controller: 'page11Ctrl'
  })

  .state('b1', {
    url: '/page12',
    templateUrl: 'templates/b1.html',
    controller: 'b1Ctrl'
  })

  .state('b2', {
    url: '/page13',
    templateUrl: 'templates/b2.html',
    controller: 'b2Ctrl'
  })

  .state('b3', {
    url: '/page14',
    templateUrl: 'templates/b3.html',
    controller: 'b3Ctrl'
  })

  .state('b4', {
    url: '/page15',
    templateUrl: 'templates/b4.html',
    controller: 'b4Ctrl'
  })

  .state('b5', {
    url: '/page16',
    templateUrl: 'templates/b5.html',
    controller: 'b5Ctrl'
  })

  .state('b6', {
    url: '/page17',
    templateUrl: 'templates/b6.html',
    controller: 'b6Ctrl'
  })

  .state('b8', {
    url: '/page18',
    templateUrl: 'templates/b8.html',
    controller: 'b8Ctrl'
  })

  .state('b7', {
    url: '/page19',
    templateUrl: 'templates/b7.html',
    controller: 'b7Ctrl'
  })

  .state('b9', {
    url: '/page20',
    templateUrl: 'templates/b9.html',
    controller: 'b9Ctrl'
  })

$urlRouterProvider.otherwise('/page1')


});